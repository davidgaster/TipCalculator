//
//  ViewController.swift
//  TipCalculatorNewest
//
//  Created by David Gaster on 3/29/16.
//  Copyright © 2016 David Gaster. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var billTextF: UITextField!
    @IBOutlet weak var taxAmountL: UILabel!
    @IBOutlet weak var tipPercentL: UILabel!
    @IBOutlet weak var tipAmountL: UILabel!
    @IBOutlet weak var currentTipValue: UISlider!
    
    // property observers
    //
    //
    // update ALL LABELS based on change of:
    // text field OR change of slider values
    //
    var billValue: Double? {
        didSet {
            updateTaxLabel()
            updateTipLabel()
            updateTotalBillLabel()
        }
        
    }
    
    var taxAmountValue: Double? {
        if let value = billValue {
            return value*0.0875
        }
        else {
            return nil
        }
    }
    
    func updateTaxLabel() {
        if let value = taxAmountValue {
            
            taxAmountL.text = numberFormatter.string(from: NSNumber(value: value))
            
        }
        else {
            taxAmountL.text = "$0.00"
        }
    }
    
    var tipAmountValue: Double? {
        
        if let tip = billValue {
            let decimal = Double(currentTipValue.value)/100
            return tip*decimal
        }
        else {
            return nil
        }
    }
    
    func updateTipLabel() {
        
        if let tip = tipAmountValue {
            tipAmountL.text = numberFormatter.string(from: NSNumber(value: tip))
        }
            
        
        else {
            tipAmountL.text = "$0.00"
        }
    }
    
    var totalBillValue: Double? {
        
        if let bill = billValue {
            if let tax = taxAmountValue {
                if let tip = tipAmountValue {
                    return (bill + tax + tip)
                }
                else {
                    return nil
                }
            }
            else {
                return nil
            }
        }
        else {
            return nil
        }
        
        
        
        
    }
    
    
    func updateTotalBillLabel() {
        
        if let text = totalBillValue {
            totalBill.text = numberFormatter.string(from: NSNumber(value: text))
        }
        else {
            totalBill.text = "$0.00"
        }
        
    }
    
    
    
    @IBAction func billValueChanged(_ sender: UITextField) {
        if let text = billTextF.text, let value = Double(text) {
            billValue = value
        }
        else {
            billValue = nil
        }
    }
    
    @IBAction func tipPercentSldr(_ sender: UISlider) {
        
        let sliderVal = round(Double(sender.value)*10)/10
        tipPercentL.text = "Tip (" + "\(sliderVal)" + "%)"
        
        updateTipLabel()
        updateTotalBillLabel()
    }
    
    @IBOutlet weak var totalBill: UILabel!
    
    
    @IBOutlet weak var mySeg: UISegmentedControl!
    @IBAction func tipSegment(_ sender: UISegmentedControl) {
        
        switch (mySeg.selectedSegmentIndex) {

        case 0: currentTipValue.value = 10
        case 1: currentTipValue.value = 15
        case 2: currentTipValue.value = 18
        case 3: currentTipValue.value = 20
        default : break
        
            
        }
        
        let sliderVal = round(Double(currentTipValue.value)*10)/10
        tipPercentL.text = "Tip (" + "\(sliderVal)" + "%)"
        
        
        updateTipLabel()
        updateTotalBillLabel()
    }
    
    // prevents user enter multiple decimal places
    func textField(_ textField: UITextField,
        shouldChangeCharactersIn range: NSRange,
        replacementString string: String) -> Bool {
            
            let existingTextHasDecimalSeparator = textField.text?.range(of: ".")
            let replacementTextHasDecimalSeparator = string.range(of: ".")
            
            if existingTextHasDecimalSeparator != nil && replacementTextHasDecimalSeparator != nil {
                
                return false
            }
            else {
                
                return true
            }
    }
    
    
    
    
    
    @IBAction func dismissKeyboard(_ sender: AnyObject) {
        billTextF.resignFirstResponder()
    }
    
    
    // number formatter to display text in Label with 
    // $ in front
    let numberFormatter: NumberFormatter = {
    let nf = NumberFormatter()
        nf.numberStyle = .currency
        nf.minimumFractionDigits = 2
        nf.maximumFractionDigits = 2
        
        return nf
        
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    // initializes slider value to 15
    currentTipValue.value = 15
    tipPercentL.text = "Tip (15%)"
    mySeg.selectedSegmentIndex = 1
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

